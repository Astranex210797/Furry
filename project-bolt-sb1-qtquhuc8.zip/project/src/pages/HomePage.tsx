import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Star, Heart, Shield, Clock } from 'lucide-react';

const HomePage = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Hero carousel images
  const heroImages = [
    'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=1200',
    'https://images.pexels.com/photos/1254140/pexels-photo-1254140.jpeg?auto=compress&cs=tinysrgb&w=1200',
    'https://images.pexels.com/photos/160846/french-bulldog-summer-smile-joy-160846.jpeg?auto=compress&cs=tinysrgb&w=1200'
  ];

  // Dog breeds data
  const breeds = [
    {
      name: 'French Mastiff',
      image: 'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=600',
      temperament: ['Gentle', 'Loyal', 'Protective'],
      size: 'Large',
      slug: 'french-mastiff'
    },
    {
      name: 'Maltese',
      image: 'https://images.pexels.com/photos/1390784/pexels-photo-1390784.jpeg?auto=compress&cs=tinysrgb&w=600',
      temperament: ['Playful', 'Gentle', 'Charming'],
      size: 'Small',
      slug: 'maltese'
    },
    {
      name: 'Toy Poodle',
      image: 'https://images.pexels.com/photos/1851164/pexels-photo-1851164.jpeg?auto=compress&cs=tinysrgb&w=600',
      temperament: ['Intelligent', 'Active', 'Alert'],
      size: 'Small',
      slug: 'toy-poodle'
    },
    {
      name: 'Yorkshire Terrier',
      image: 'https://images.pexels.com/photos/825949/pexels-photo-825949.jpeg?auto=compress&cs=tinysrgb&w=600',
      temperament: ['Bold', 'Independent', 'Confident'],
      size: 'Small',
      slug: 'yorkshire-terrier'
    }
  ];

  // Testimonials data
  const testimonials = [
    {
      name: 'Sarah Johnson',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      text: 'FurryFriend helped us find our perfect companion. Max has brought so much joy to our family!',
      rating: 5,
      dogName: 'Max'
    },
    {
      name: 'Mike Chen',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
      text: 'The adoption process was smooth and transparent. Luna is everything we dreamed of and more.',
      rating: 5,
      dogName: 'Luna'
    },
    {
      name: 'Emily Rodriguez',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
      text: 'Professional service with genuine care for the dogs. Highly recommend FurryFriend!',
      rating: 5,
      dogName: 'Bella'
    }
  ];

  // Auto-rotate carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroImages.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroImages.length) % heroImages.length);
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[70vh] overflow-hidden rounded-b-3xl">
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={image}
                alt="Adorable dogs"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent"></div>
            </div>
          ))}
        </div>

        {/* Carousel Controls */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-3 rounded-full shadow-lg transition-all hover:scale-110"
        >
          <ChevronLeft className="h-6 w-6 text-gray-800" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-3 rounded-full shadow-lg transition-all hover:scale-110"
        >
          <ChevronRight className="h-6 w-6 text-gray-800" />
        </button>

        {/* Hero Content */}
        <div className="absolute inset-0 flex items-center justify-center text-center">
          <div className="max-w-4xl mx-auto px-4">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Find Your Furry
              <span className="block gradient-text-warm">
                Forever Friend
              </span>
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Connecting loving families with adorable, healthy puppies. Your perfect companion is waiting for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#breeds"
                className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
              >
                Meet Our Breeds
              </a>
              <Link
                to="/contact"
                className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
              >
                Get In Touch
              </Link>
            </div>
          </div>
        </div>

        {/* Carousel Indicators */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white scale-125' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-300">
                <Heart className="h-12 w-12 text-orange-600 mx-auto" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Love at First Sight</h3>
              <p className="text-gray-600">Each puppy is carefully selected and raised with love to ensure they're ready for their forever home.</p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gradient-to-br from-blue-100 to-cyan-100 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-300">
                <Shield className="h-12 w-12 text-blue-600 mx-auto" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Health Guaranteed</h3>
              <p className="text-gray-600">All our puppies come with health certificates and are fully vaccinated by certified veterinarians.</p>
            </div>
            
            <div className="text-center group">
              <div className="bg-gradient-to-br from-green-100 to-emerald-100 p-6 rounded-2xl mb-4 group-hover:scale-105 transition-transform duration-300">
                <Clock className="h-12 w-12 text-green-600 mx-auto" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Lifetime Support</h3>
              <p className="text-gray-600">We provide ongoing support and guidance to ensure your puppy grows into a happy, healthy adult dog.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Breeds Showcase */}
      <section id="breeds" className="py-16 px-4 bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Meet Our Amazing Breeds
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Each breed has unique characteristics. Find the perfect match for your lifestyle and family.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {breeds.map((breed) => (
              <div key={breed.name} className="group cursor-pointer">
                <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group-hover:scale-[1.02] transform">
                  <div className="relative overflow-hidden">
                    <img
                      src={breed.image}
                      alt={breed.name}
                      className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="flex flex-wrap gap-1">
                        {breed.temperament.map((trait) => (
                          <span key={trait} className="text-xs bg-white/20 backdrop-blur-sm px-2 py-1 rounded-full">
                            {trait}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{breed.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">Size: {breed.size}</p>
                    <Link
                      to={`/breed/${breed.slug}`}
                      className="inline-flex items-center text-orange-600 hover:text-orange-700 font-medium group-hover:translate-x-1 transition-transform duration-300"
                    >
                      Learn More →
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Happy Families, Happy Pets
            </h2>
            <p className="text-xl text-gray-600">
              Don't just take our word for it - hear from our wonderful families!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic mb-2">"{testimonial.text}"</p>
                <p className="text-orange-600 font-medium">- {testimonial.dogName}'s family</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-500 to-pink-500">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Find Your Perfect Match?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Start your journey to unconditional love today. Our team is here to help you every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
            >
              Start Your Journey
            </Link>
            <Link
              to="/adoption-process"
              className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
            >
              Learn Our Process
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
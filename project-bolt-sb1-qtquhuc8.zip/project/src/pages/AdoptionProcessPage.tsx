import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Users, Heart, Home, CheckCircle, Star, Clock, Shield } from 'lucide-react';

const AdoptionProcessPage = () => {
  const steps = [
    {
      icon: FileText,
      title: 'Application',
      description: 'Fill out our simple online application to tell us about your family and preferences.',
      details: [
        'Basic family information',
        'Living situation details',
        'Previous pet experience',
        'Breed preferences'
      ],
      duration: '5 minutes'
    },
    {
      icon: Users,
      title: 'Consultation',
      description: 'We schedule a phone or video call to discuss your needs and answer any questions.',
      details: [
        'Lifestyle compatibility',
        'Breed recommendations',
        'Care requirements',
        'Timeline discussion'
      ],
      duration: '30 minutes'
    },
    {
      icon: Heart,
      title: 'Meet & Greet',
      description: 'Visit our facility to meet available puppies and find your perfect match.',
      details: [
        'Hands-on interaction',
        'Temperament assessment',
        'Health information',
        'Care guidance'
      ],
      duration: '1-2 hours'
    },
    {
      icon: Home,
      title: 'Welcome Home',
      description: 'Take your new family member home with all necessary supplies and support.',
      details: [
        'Health documentation',
        'Care kit included',
        'Ongoing support',
        'Follow-up check-ins'
      ],
      duration: 'Lifetime'
    }
  ];

  const benefits = [
    {
      icon: Shield,
      title: 'Health Guarantee',
      description: 'Comprehensive health screening and veterinary certification for all puppies.'
    },
    {
      icon: Star,
      title: 'Quality Breeding',
      description: 'Working exclusively with certified, ethical breeders who prioritize health and temperament.'
    },
    {
      icon: Clock,
      title: 'Lifetime Support',
      description: 'Ongoing guidance and support throughout your dog\'s entire life.'
    },
    {
      icon: CheckCircle,
      title: 'Satisfaction Promise',
      description: 'Your happiness and your puppy\'s wellbeing are our top priorities.'
    }
  ];

  const requirements = [
    'Must be 21 years or older',
    'Stable living situation',
    'Commitment to provide lifelong care',
    'Agreement to spay/neuter (if not already done)',
    'References from veterinarian (if applicable)'
  ];

  const included = [
    'Complete health documentation',
    'Vaccination records',
    'Microchip registration',
    'Starter care package',
    'Training resources',
    'Lifetime support hotline'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Adoption Process
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We've designed a simple, transparent process to ensure every puppy finds their perfect forever home. 
            Your journey to unconditional love starts here.
          </p>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Simple Steps to Your New Best Friend
            </h2>
            <p className="text-xl text-gray-600">
              Our caring team guides you through each step
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm z-10">
                  {index + 1}
                </div>
                
                {/* Card */}
                <div className="bg-white rounded-2xl shadow-lg p-6 h-full hover:shadow-xl transition-shadow duration-300">
                  <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-4 rounded-2xl inline-flex mb-4">
                    <step.icon className="h-8 w-8 text-orange-600" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{step.title}</h3>
                  <p className="text-gray-600 mb-4">{step.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    {step.details.map((detail, detailIndex) => (
                      <div key={detailIndex} className="flex items-center text-sm text-gray-500">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                        {detail}
                      </div>
                    ))}
                  </div>
                  
                  <div className="text-orange-600 font-medium text-sm">
                    Duration: {step.duration}
                  </div>
                </div>
                
                {/* Arrow (hidden on last item) */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-0">
                    <div className="w-8 h-0.5 bg-gradient-to-r from-orange-200 to-pink-200"></div>
                    <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-0 h-0 border-l-4 border-r-0 border-t-2 border-b-2 border-l-orange-300 border-t-transparent border-b-transparent"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Why Choose FurryFriend?
            </h2>
            <p className="text-xl text-gray-600">
              We go above and beyond to ensure your peace of mind
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300">
                <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-4 rounded-2xl inline-flex mb-4">
                  <benefit.icon className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Requirements & Included */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Requirements */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold gradient-text mb-6">Adoption Requirements</h2>
              <p className="text-gray-600 mb-6">
                To ensure our puppies go to loving, responsible homes, we have a few simple requirements:
              </p>
              <ul className="space-y-3">
                {requirements.map((requirement, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{requirement}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* What's Included */}
            <div className="bg-gradient-to-br from-orange-50 to-pink-50 rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold gradient-text mb-6">What's Included</h2>
              <p className="text-gray-600 mb-6">
                Every adoption includes everything you need for a smooth transition:
              </p>
              <ul className="space-y-3">
                {included.map((item, index) => (
                  <li key={index} className="flex items-center">
                    <Star className="h-5 w-5 text-orange-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold gradient-text mb-4">
              Expected Timeline
            </h2>
            <p className="text-xl text-gray-600">
              Here's what to expect throughout the process
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-orange-200 to-pink-200"></div>
            
            <div className="space-y-12">
              <div className="flex items-center">
                <div className="flex-1 text-right pr-8">
                  <h3 className="text-lg font-bold text-gray-800">Day 1-2</h3>
                  <p className="text-gray-600">Application submitted and reviewed</p>
                </div>
                <div className="w-4 h-4 bg-orange-500 rounded-full relative z-10"></div>
                <div className="flex-1 pl-8">
                  <div className="text-gray-500">Initial screening and background check</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-1 text-right pr-8">
                  <div className="text-gray-500">Phone or video consultation</div>
                </div>
                <div className="w-4 h-4 bg-orange-500 rounded-full relative z-10"></div>
                <div className="flex-1 pl-8">
                  <h3 className="text-lg font-bold text-gray-800">Day 3-5</h3>
                  <p className="text-gray-600">Consultation scheduled</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-1 text-right pr-8">
                  <h3 className="text-lg font-bold text-gray-800">Day 7-10</h3>
                  <p className="text-gray-600">Visit scheduled and completed</p>
                </div>
                <div className="w-4 h-4 bg-orange-500 rounded-full relative z-10"></div>
                <div className="flex-1 pl-8">
                  <div className="text-gray-500">Meet puppies and make your choice</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-1 text-right pr-8">
                  <div className="text-gray-500">Take your new friend home!</div>
                </div>
                <div className="w-4 h-4 bg-pink-500 rounded-full relative z-10"></div>
                <div className="flex-1 pl-8">
                  <h3 className="text-lg font-bold text-gray-800">Day 14</h3>
                  <p className="text-gray-600">Adoption finalized</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-500 to-pink-500">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Your perfect furry companion is waiting for you. Let's begin this wonderful adventure together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
            >
              Start Application
            </Link>
            <Link
              to="/#breeds"
              className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-8 py-4 rounded-full font-semibold text-lg transition-all hover:shadow-lg transform hover:scale-105"
            >
              Browse Breeds
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AdoptionProcessPage;
import React from 'react';
import { Heart, Award, Users, Shield, Star, MapPin } from 'lucide-react';

const AboutPage = () => {
  const values = [
    {
      icon: Heart,
      title: 'Love & Care',
      description: 'Every puppy receives individual attention and love from our dedicated team.'
    },
    {
      icon: Shield,
      title: 'Health First',
      description: 'Comprehensive health screenings and veterinary care for all our puppies.'
    },
    {
      icon: Users,
      title: 'Family Focus',
      description: 'We help match families with the perfect furry companion for their lifestyle.'
    },
    {
      icon: Award,
      title: 'Quality Breeding',
      description: 'Working only with certified, ethical breeders who share our values.'
    }
  ];

  const team = [
    {
      name: 'Sarah Mitchell',
      role: 'Founder & CEO',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: '10+ years experience in animal care and breeding'
    },
    {
      name: 'Dr. James Wilson',
      role: 'Chief Veterinarian',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: 'Certified veterinarian specializing in puppy health'
    },
    {
      name: 'Emily Rodriguez',
      role: 'Puppy Care Specialist',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=300',
      bio: 'Expert in puppy behavior and early development'
    }
  ];

  const stats = [
    { number: '500+', label: 'Happy Families' },
    { number: '4', label: 'Premium Breeds' },
    { number: '10+', label: 'Years Experience' },
    { number: '99%', label: 'Customer Satisfaction' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            About FurryFriend
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            For over a decade, we've been connecting loving families with their perfect furry companions. 
            Our mission is simple: to ensure every puppy finds a forever home filled with love, care, and happiness.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-orange-100 to-pink-100 rounded-2xl p-6 mb-4">
                  <div className="text-3xl md:text-4xl font-bold text-orange-600 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600 font-medium">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold gradient-text mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  FurryFriend was born from a simple belief: every family deserves the unconditional love 
                  that only a furry companion can provide. Founded in 2013 by Sarah Mitchell, our journey 
                  began with a rescue dog named Buddy who changed everything.
                </p>
                <p>
                  After witnessing firsthand the incredible bond between humans and dogs, Sarah dedicated 
                  her life to connecting families with their perfect matches. What started as a small 
                  operation has grown into a trusted network of ethical breeders and satisfied families.
                </p>
                <p>
                  Today, we're proud to have helped over 500 families find their furry forever friends, 
                  and we're just getting started. Each success story fuels our passion to continue this 
                  meaningful work.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Happy family with dog"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-orange-500 to-pink-500 text-white p-6 rounded-2xl shadow-lg">
                <Star className="h-8 w-8 mb-2" />
                <div className="text-2xl font-bold">4.9/5</div>
                <div className="text-sm">Customer Rating</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Our Values
            </h2>
            <p className="text-xl text-gray-600">
              Everything we do is guided by these core principles
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300">
                <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-4 rounded-2xl inline-flex mb-4">
                  <value.icon className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Meet Our Team */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600">
              The passionate people behind FurryFriend
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-1">{member.name}</h3>
                  <p className="text-orange-600 font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location & Contact */}
      <section className="py-16 bg-gradient-to-r from-orange-500 to-pink-500">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Visit Our Facility
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            We welcome families to visit our clean, safe facility to meet our puppies and see 
            firsthand the care and love they receive.
          </p>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-2xl mx-auto">
            <div className="flex items-center justify-center mb-4">
              <MapPin className="h-6 w-6 text-white mr-2" />
              <span className="text-white font-semibold">Our Location</span>
            </div>
            <p className="text-white/90 mb-2">123 Puppy Lane, Happy Valley, CA 90210</p>
            <p className="text-white/90 mb-6">Open Monday - Saturday, 9 AM - 6 PM</p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:+15551234567"
                className="bg-white text-orange-600 hover:bg-gray-100 px-6 py-3 rounded-full font-semibold transition-all hover:shadow-lg transform hover:scale-105"
              >
                Call to Schedule
              </a>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-6 py-3 rounded-full font-semibold transition-all hover:shadow-lg transform hover:scale-105"
              >
                Get Directions
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
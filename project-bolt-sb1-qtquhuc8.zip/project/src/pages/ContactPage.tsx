import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, MessageCircle } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    interest: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const contactMethods = [
    {
      icon: Phone,
      title: 'Call Us',
      detail: '+1 (555) 123-PAWS',
      action: 'tel:+15551234567',
      description: 'Call us for immediate assistance'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      detail: '+1 (555) 123-PAWS',
      action: 'https://wa.me/15551234567',
      description: 'Chat with us on WhatsApp'
    },
    {
      icon: Mail,
      title: 'Email',
      detail: 'hello@furryfriend.com',
      action: 'mailto:hello@furryfriend.com',
      description: 'Send us an email'
    }
  ];

  const businessInfo = [
    {
      icon: Clock,
      title: 'Business Hours',
      details: ['Monday - Friday: 9 AM - 6 PM', 'Saturday: 10 AM - 4 PM', 'Sunday: Closed']
    },
    {
      icon: MapPin,
      title: 'Location',
      details: ['123 Puppy Lane', 'Happy Valley, CA 90210', 'United States']
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Get In Touch
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ready to find your perfect furry friend? We're here to help you every step of the way. 
            Reach out to us and let's start this beautiful journey together.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div>
            <h2 className="text-3xl font-bold gradient-text mb-6">Send Us a Message</h2>
            <p className="text-gray-600 mb-8">
              Fill out the form below and we'll get back to you within 24 hours.
            </p>

            {submitted && (
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-xl mb-6">
                Thank you! We'll be in touch soon.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Interested In
                  </label>
                  <select
                    name="interest"
                    value={formData.interest}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                  >
                    <option value="">Select a breed</option>
                    <option value="french-mastiff">French Mastiff</option>
                    <option value="maltese">Maltese</option>
                    <option value="toy-poodle">Toy Poodle</option>
                    <option value="yorkshire-terrier">Yorkshire Terrier</option>
                    <option value="general">General Inquiry</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Message *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none"
                  placeholder="Tell us about your family, lifestyle, and what you're looking for in a furry friend..."
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white py-4 rounded-xl font-semibold transition-all hover:shadow-lg transform hover:scale-[1.02]"
              >
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div>
            <h2 className="text-3xl font-bold gradient-text mb-6">Contact Information</h2>
            
            {/* Contact Methods */}
            <div className="space-y-6 mb-8">
              {contactMethods.map((method, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                  <div className="flex items-center mb-4">
                    <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-3 rounded-xl mr-4">
                      <method.icon className="h-6 w-6 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">{method.title}</h3>
                      <p className="text-gray-600 text-sm">{method.description}</p>
                    </div>
                  </div>
                  <a
                    href={method.action}
                    className="text-orange-600 hover:text-orange-700 font-medium block transition-colors"
                  >
                    {method.detail}
                  </a>
                </div>
              ))}
            </div>

            {/* Business Information */}
            <div className="space-y-6">
              {businessInfo.map((info, index) => (
                <div key={index} className="bg-gradient-to-br from-orange-50 to-pink-50 rounded-2xl p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-white p-3 rounded-xl mr-4 shadow-sm">
                      <info.icon className="h-6 w-6 text-orange-600" />
                    </div>
                    <h3 className="font-bold text-gray-800">{info.title}</h3>
                  </div>
                  <div className="ml-16 space-y-1">
                    {info.details.map((detail, detailIndex) => (
                      <p key={detailIndex} className="text-gray-600">{detail}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Map Placeholder */}
            <div className="mt-8 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl p-8 text-center">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-bold text-gray-600 mb-2">Interactive Map</h3>
              <p className="text-gray-500 text-sm">
                Click to view our location on Google Maps
              </p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mt-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all transform hover:scale-105"
              >
                View on Maps
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <section className="bg-gradient-to-br from-orange-50 to-pink-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold gradient-text text-center mb-12">
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-6">
            {[
              {
                question: "How do I know if a puppy is right for my family?",
                answer: "We offer consultations to help match your family's lifestyle, living situation, and preferences with the perfect breed and individual puppy."
              },
              {
                question: "What health guarantees do you provide?",
                answer: "All our puppies come with health certificates, vaccination records, and a health guarantee. We work only with certified veterinarians."
              },
              {
                question: "Can I visit the puppies before adopting?",
                answer: "Absolutely! We encourage families to visit our facility and meet the puppies. This helps ensure the perfect match for everyone."
              },
              {
                question: "What is your adoption process?",
                answer: "Our process includes an application, consultation, meet and greet, and preparation guidance. We're with you every step of the way."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="font-bold text-gray-800 mb-3">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Heart, Star, Users, Home, Zap, Shield } from 'lucide-react';

const BreedDetailPage = () => {
  const { breedName } = useParams();

  // Breed data (in a real app, this would come from an API or database)
  const breedData: { [key: string]: any } = {
    'french-mastiff': {
      name: 'French Mastiff',
      scientificName: 'Dogue de Bordeaux',
      images: [
        'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1254140/pexels-photo-1254140.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/160846/french-bulldog-summer-smile-joy-160846.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      overview: 'The French Mastiff, also known as Dogue de Bordeaux, is a powerful, muscular breed with a distinctive wrinkled face and gentle temperament. Despite their imposing size, they are known for being loyal family companions.',
      temperament: ['Gentle', 'Loyal', 'Protective', 'Calm', 'Affectionate'],
      size: 'Large (99-110 lbs)',
      lifespan: '5-8 years',
      energyLevel: 'Moderate',
      groomingNeeds: 'Low',
      trainability: 'Moderate',
      goodWithKids: true,
      goodWithPets: true,
      history: 'Originally bred in France for guarding and hunting, the French Mastiff has a rich history dating back to ancient times. They were used by French aristocracy and later became beloved family companions.',
      care: {
        exercise: 'Daily walks and moderate playtime. Avoid overexertion due to their breathing.',
        grooming: 'Weekly brushing and regular face cleaning. Minimal shedding.',
        health: 'Regular vet checkups, heart monitoring, and joint care are essential.',
        diet: 'High-quality large breed dog food, 3-4 cups daily, divided into meals.'
      },
      lifestyle: [
        { icon: Home, text: 'Best for houses with yards' },
        { icon: Users, text: 'Great with families and children' },
        { icon: Shield, text: 'Natural protective instincts' },
        { icon: Heart, text: 'Extremely loyal and affectionate' }
      ]
    },
    'maltese': {
      name: 'Maltese',
      scientificName: 'Canis lupus familiaris',
      images: [
        'https://images.pexels.com/photos/1390784/pexels-photo-1390784.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/4587998/pexels-photo-4587998.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/7210754/pexels-photo-7210754.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      overview: 'The Maltese is a small toy breed known for its silky white coat and gentle, playful nature. They make excellent companions and are particularly well-suited for apartment living.',
      temperament: ['Playful', 'Gentle', 'Charming', 'Responsive', 'Fearless'],
      size: 'Small (4-7 lbs)',
      lifespan: '12-15 years',
      energyLevel: 'Moderate',
      groomingNeeds: 'High',
      trainability: 'High',
      goodWithKids: true,
      goodWithPets: true,
      history: 'The Maltese is one of the oldest toy breeds, with origins tracing back to ancient Mediterranean civilizations. They were favored by nobility and have been cherished companions for over 2,000 years.',
      care: {
        exercise: 'Daily indoor play and short walks. Perfect for apartment living.',
        grooming: 'Daily brushing required to prevent matting. Professional grooming monthly.',
        health: 'Regular dental care, eye cleaning, and joint monitoring.',
        diet: 'High-quality small breed dog food, 1/4 to 1/2 cup daily.'
      },
      lifestyle: [
        { icon: Home, text: 'Perfect for apartments' },
        { icon: Users, text: 'Excellent companion dogs' },
        { icon: Heart, text: 'Affectionate and devoted' },
        { icon: Star, text: 'Low exercise requirements' }
      ]
    },
    'toy-poodle': {
      name: 'Toy Poodle',
      scientificName: 'Canis lupus familiaris',
      images: [
        'https://images.pexels.com/photos/1851164/pexels-photo-1851164.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/406014/pexels-photo-406014.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/1254140/pexels-photo-1254140.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      overview: 'Toy Poodles are intelligent, active, and elegant dogs with curly hypoallergenic coats. They are highly trainable and make excellent companions for active families.',
      temperament: ['Intelligent', 'Active', 'Alert', 'Trainable', 'Friendly'],
      size: 'Small (4-6 lbs)',
      lifespan: '12-15 years',
      energyLevel: 'High',
      groomingNeeds: 'High',
      trainability: 'Very High',
      goodWithKids: true,
      goodWithPets: true,
      history: 'Originally bred as water retrievers, Poodles were later miniaturized to create the Toy variety. They have been popular in European courts and circuses due to their intelligence and trainability.',
      care: {
        exercise: 'Daily walks and mental stimulation. Enjoys interactive toys and games.',
        grooming: 'Professional grooming every 6-8 weeks. Daily brushing to prevent matting.',
        health: 'Regular eye and ear care. Monitor for luxating patella and hip dysplasia.',
        diet: 'High-quality small breed food, 1/4 to 1/2 cup daily, divided into meals.'
      },
      lifestyle: [
        { icon: Zap, text: 'High energy and intelligence' },
        { icon: Users, text: 'Great with children' },
        { icon: Star, text: 'Hypoallergenic coat' },
        { icon: Heart, text: 'Extremely loyal' }
      ]
    },
    'yorkshire-terrier': {
      name: 'Yorkshire Terrier',
      scientificName: 'Canis lupus familiaris',
      images: [
        'https://images.pexels.com/photos/825949/pexels-photo-825949.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/2023384/pexels-photo-2023384.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/4148831/pexels-photo-4148831.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      overview: 'Yorkshire Terriers are small dogs with big personalities. They are brave, determined, and energetic, making them excellent watchdogs despite their tiny size.',
      temperament: ['Bold', 'Independent', 'Confident', 'Courageous', 'Energetic'],
      size: 'Small (4-7 lbs)',
      lifespan: '13-16 years',
      energyLevel: 'High',
      groomingNeeds: 'High',
      trainability: 'Moderate',
      goodWithKids: false,
      goodWithPets: false,
      history: 'Developed in Yorkshire, England during the 19th century, Yorkies were originally bred to catch rats in textile mills. They later became fashionable companions among Victorian ladies.',
      care: {
        exercise: 'Daily walks and indoor play. Enjoys mental stimulation and games.',
        grooming: 'Daily brushing required. Professional grooming every 6-8 weeks.',
        health: 'Dental care is crucial. Monitor for luxating patella and tracheal collapse.',
        diet: 'High-quality small breed food, 1/2 to 3/4 cup daily, divided into small meals.'
      },
      lifestyle: [
        { icon: Shield, text: 'Excellent watchdog' },
        { icon: Zap, text: 'High energy in small package' },
        { icon: Star, text: 'Minimal shedding' },
        { icon: Heart, text: 'Devoted to family' }
      ]
    }
  };

  const breed = breedData[breedName || ''];

  if (!breed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Breed not found</h1>
          <Link to="/" className="text-orange-600 hover:text-orange-700">
            ← Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-br from-orange-50 to-pink-50 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <Link
            to="/"
            className="inline-flex items-center text-orange-600 hover:text-orange-700 mb-4 group"
          >
            <ArrowLeft className="h-5 w-5 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-2">
            {breed.name}
          </h1>
          <p className="text-xl text-gray-600 italic">{breed.scientificName}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Image Gallery */}
          <div>
            <div className="grid grid-cols-1 gap-4">
              {breed.images.map((image: string, index: number) => (
                <div key={index} className="overflow-hidden rounded-2xl shadow-lg">
                  <img
                    src={image}
                    alt={`${breed.name} ${index + 1}`}
                    className="w-full h-64 object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Breed Information */}
          <div className="space-y-8">
            {/* Overview */}
            <div>
              <h2 className="text-2xl font-bold gradient-text mb-4">Overview</h2>
              <p className="text-gray-600 leading-relaxed">{breed.overview}</p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-orange-100 to-pink-100 p-4 rounded-xl">
                <h3 className="font-semibold text-gray-800 mb-2">Size</h3>
                <p className="text-gray-600">{breed.size}</p>
              </div>
              <div className="bg-gradient-to-br from-blue-100 to-cyan-100 p-4 rounded-xl">
                <h3 className="font-semibold text-gray-800 mb-2">Lifespan</h3>
                <p className="text-gray-600">{breed.lifespan}</p>
              </div>
              <div className="bg-gradient-to-br from-green-100 to-emerald-100 p-4 rounded-xl">
                <h3 className="font-semibold text-gray-800 mb-2">Energy Level</h3>
                <p className="text-gray-600">{breed.energyLevel}</p>
              </div>
              <div className="bg-gradient-to-br from-purple-100 to-pink-100 p-4 rounded-xl">
                <h3 className="font-semibold text-gray-800 mb-2">Grooming</h3>
                <p className="text-gray-600">{breed.groomingNeeds}</p>
              </div>
            </div>

            {/* Temperament */}
            <div>
              <h2 className="text-2xl font-bold gradient-text mb-4">Temperament</h2>
              <div className="flex flex-wrap gap-2">
                {breed.temperament.map((trait: string, index: number) => (
                  <span
                    key={index}
                    className="bg-gradient-to-r from-orange-100 to-pink-100 text-orange-700 px-4 py-2 rounded-full text-sm font-medium"
                  >
                    {trait}
                  </span>
                ))}
              </div>
            </div>

            {/* Lifestyle Compatibility */}
            <div>
              <h2 className="text-2xl font-bold gradient-text mb-4">Lifestyle Compatibility</h2>
              <div className="space-y-3">
                {breed.lifestyle.map((item: any, index: number) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="bg-gradient-to-r from-orange-500 to-pink-500 p-2 rounded-full">
                      <item.icon className="h-5 w-5 text-white" />
                    </div>
                    <span className="text-gray-700">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Sections */}
        <div className="mt-16 grid md:grid-cols-2 gap-12">
          {/* History */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold gradient-text mb-4">History & Background</h2>
            <p className="text-gray-600 leading-relaxed">{breed.history}</p>
          </div>

          {/* Care Guide */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold gradient-text mb-4">Care Guide</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Exercise</h3>
                <p className="text-gray-600 text-sm">{breed.care.exercise}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Grooming</h3>
                <p className="text-gray-600 text-sm">{breed.care.grooming}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Health</h3>
                <p className="text-gray-600 text-sm">{breed.care.health}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Diet</h3>
                <p className="text-gray-600 text-sm">{breed.care.diet}</p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl p-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Welcome a {breed.name}?
          </h2>
          <p className="text-white/90 mb-6">
            Our team is here to help you find the perfect {breed.name} puppy for your family.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-3 rounded-full font-semibold transition-all hover:shadow-lg transform hover:scale-105"
            >
              Get In Touch
            </Link>
            <Link
              to="/adoption-process"
              className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white hover:bg-white/20 px-8 py-3 rounded-full font-semibold transition-all hover:shadow-lg transform hover:scale-105"
            >
              Learn Our Process
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BreedDetailPage;
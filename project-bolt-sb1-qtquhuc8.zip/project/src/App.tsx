import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import FloatingContacts from './components/FloatingContacts';
import HomePage from './pages/HomePage';
import BreedDetailPage from './pages/BreedDetailPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import AdoptionProcessPage from './pages/AdoptionProcessPage';
import ContactModal from './components/ContactModal';
import ScrollToTop from './components/ScrollToTop';

function App() {
  const [showContactModal, setShowContactModal] = useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/breed/:breedName" element={<BreedDetailPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/adoption-process" element={<AdoptionProcessPage />} />
          </Routes>
        </main>
        <Footer />
        <FloatingContacts onContactClick={() => setShowContactModal(true)} />
        {showContactModal && (
          <ContactModal onClose={() => setShowContactModal(false)} />
        )}
        <ScrollToTop />
      </div>
    </Router>
  );
}

export default App;
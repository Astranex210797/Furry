import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Instagram, Facebook, Mail, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-orange-100 to-pink-100 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand Section */}
          <div className="text-center md:text-left">
            <Link to="/" className="flex items-center space-x-2 justify-center md:justify-start mb-4 group">
              <div className="bg-gradient-to-r from-orange-200 to-pink-200 p-2 rounded-full group-hover:scale-110 transition-transform duration-300">
                <Heart className="h-6 w-6 text-orange-600" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
                FurryFriend
              </span>
            </Link>
            <p className="text-gray-600 text-sm leading-relaxed">
              Connecting hearts with paws<br />
              Finding forever homes for furry friends
            </p>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h3 className="font-semibold text-gray-800 mb-4">Quick Links</h3>
            <div className="space-y-2">
              <Link to="/" className="block text-gray-600 hover:text-orange-600 text-sm transition-colors">
                Home
              </Link>
              <Link to="/#breeds" className="block text-gray-600 hover:text-orange-600 text-sm transition-colors">
                Our Breeds
              </Link>
              <Link to="/adoption-process" className="block text-gray-600 hover:text-orange-600 text-sm transition-colors">
                Adoption Process
              </Link>
              <Link to="/about" className="block text-gray-600 hover:text-orange-600 text-sm transition-colors">
                About Us
              </Link>
              <Link to="/contact" className="block text-gray-600 hover:text-orange-600 text-sm transition-colors">
                Contact Us
              </Link>
            </div>
          </div>

          {/* Contact & Social */}
          <div className="text-center md:text-right">
            <h3 className="font-semibold text-gray-800 mb-4">Get In Touch</h3>
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-center md:justify-end space-x-2">
                <Phone className="h-4 w-4 text-orange-600" />
                <span className="text-gray-600 text-sm">+1 (555) 123-PAWS</span>
              </div>
              <div className="flex items-center justify-center md:justify-end space-x-2">
                <Mail className="h-4 w-4 text-orange-600" />
                <span className="text-gray-600 text-sm">hello@furryfriend.com</span>
              </div>
            </div>
            <div className="flex space-x-4 justify-center md:justify-end">
              <a href="#" className="text-gray-400 hover:text-pink-600 transition-colors p-2 rounded-full hover:bg-pink-100">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors p-2 rounded-full hover:bg-blue-100">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-orange-200 mt-8 pt-6 text-center">
          <p className="text-gray-600 text-sm flex items-center justify-center space-x-1">
            <span>Because every friend deserves a forever home</span>
            <Heart className="h-4 w-4 text-pink-500 animate-pulse" />
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
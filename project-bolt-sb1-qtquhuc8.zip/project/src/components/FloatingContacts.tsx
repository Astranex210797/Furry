import React, { useState } from 'react';
import { MessageCircle, Phone, Mail, X } from 'lucide-react';

interface FloatingContactsProps {
  onContactClick: () => void;
}

const FloatingContacts: React.FC<FloatingContactsProps> = ({ onContactClick }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const contacts = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-green-500 hover:bg-green-600',
      action: () => window.open('https://wa.me/15551234567', '_blank')
    },
    {
      name: 'Call Now',
      icon: Phone,
      color: 'bg-yellow-500 hover:bg-yellow-600',
      action: () => window.open('tel:+15551234567', '_blank')
    },
    {
      name: 'Get in Touch',
      icon: Mail,
      color: 'bg-blue-500 hover:bg-blue-600',
      action: onContactClick
    }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="flex flex-col items-end space-y-3">
        {/* Contact Options */}
        {isExpanded && (
          <div className="flex flex-col items-end space-y-3 animate-in slide-in-from-bottom duration-300">
            {contacts.map((contact, index) => (
              <div key={contact.name} className="group relative">
                {/* Tooltip */}
                <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-800 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                  {contact.name}
                  <div className="absolute top-1/2 -translate-y-1/2 -right-1 w-2 h-2 bg-gray-800 rotate-45"></div>
                </div>
                
                <button
                  onClick={contact.action}
                  className={`${contact.color} text-white p-4 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-300 group`}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <contact.icon className="h-6 w-6" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Main Toggle Button */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-300 ${
            isExpanded ? 'rotate-45' : ''
          }`}
        >
          {isExpanded ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
        </button>
      </div>
    </div>
  );
};

export default FloatingContacts;